export default function Page() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-2 text-center">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">Reports</p>
      <h1 className="font-display text-xl font-bold text-fg">Shift History Report</h1>
      <p className="max-w-sm text-sm text-muted">
        This screen is a placeholder for now — the real page will be built here.
      </p>
    </div>
  );
}
